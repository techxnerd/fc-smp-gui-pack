FC-SMP Server Pack v1.1.0
Minecraft Java 1.21.11 / Purpur 1.21.11

Includes: FCPoseStudio Java visuals, Staff Toolkit item models, and FC-SMP GUI pagination icons.
Bedrock parity for FCPoseStudio segmented-player rendering is not implemented; Bedrock pack covers Staff Toolkit and GUI icons.
