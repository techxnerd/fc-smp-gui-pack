FC-SMP Server Pack v1.3.0
Java 1.21.11: Pose Studio 0.7.1, Staff Toolkit, pagination icons, Faction/War/Elite/Vote crate visuals, FC TokenShop visuals, Factions visuals, and Tutorial visuals.
Bedrock parity: Staff Toolkit, pagination icons, crate/key mappings, FC TokenShop mappings, Factions mappings, and Tutorial mappings.
Pose Studio segmented-player rendering remains Java-only.
