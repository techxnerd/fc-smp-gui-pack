FC-SMP mandatory Java server pack v1.3.2
Staff + GUI + Crates + Tokens + Factions + Tutorial + branded sound events.
Shader-safe default: no FC Pose core entity shader override.
